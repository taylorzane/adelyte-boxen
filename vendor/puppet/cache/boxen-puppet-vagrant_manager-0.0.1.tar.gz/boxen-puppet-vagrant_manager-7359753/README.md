# Vagrant Manager Puppet Module for Boxen
[![Build Status](https://travis-ci.org/pauloconnor/puppet-vagrant_manager.png?branch=master)](https://travis-ci.org/pauloconnor/puppet-vagrant_manager)

Installs [Vagrant Manager](https://vagrantmanager.com) app

## Usage

```puppet
include vagrant_manager
```

## Required Puppet Modules

* boxen